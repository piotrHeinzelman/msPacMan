//
// Created by Bill on 8/28/2023.
//

#ifndef MSPACMAN_DIRECT_H
#define MSPACMAN_DIRECT_H

typedef  enum  { N=0, W=1, S=2, E=3, STOP=4 } DIRECT;

#endif //MSPACMAN_DIRECT_H
