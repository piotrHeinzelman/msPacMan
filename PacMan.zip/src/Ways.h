//
// Created by John on 9/4/2023.
//

#ifndef MSPACMAN_WAYS_H
#define MSPACMAN_WAYS_H


#include "Bridge.h"

class Bridge;

struct Ways {
    Bridge* n;
    Bridge* w;
    Bridge* s;
    Bridge* e;
};


#endif //MSPACMAN_WAYS_H
