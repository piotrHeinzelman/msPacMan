//
// Created by John on 9/4/2023.
//

#ifndef MSPACMAN_SECONDTEST_H
#define MSPACMAN_SECONDTEST_H


class SecondTest {
public:
    void runTest();


private:

};


#endif //MSPACMAN_SECONDTEST_H
