//
// Created by Bill on 8/30/2023.
//

#ifndef MSPACMAN_CPPTESTS_H
#define MSPACMAN_CPPTESTS_H

#include "../src/Bridges.h"


class CppTests {

public:
    void BridgesTest();

};


#endif //MSPACMAN_CPPTESTS_H
